package com.capgemini.entities;

import java.io.Serializable;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.NumberFormat;
import org.springframework.format.annotation.NumberFormat.Style;

@Entity
@Table(name="Employee")
public class Employee implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="emp_Id")
	private int emp_Id;
	
	@NotEmpty(message="First Name cannot be empty")
	@Column(name="emp_First_Name")
	private String emp_First_Name;
	
	@NotEmpty(message="Last Name cannot be empty")
	@Column(name="emp_Last_Name")
	private String emp_Last_Name;
	
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Column(name="emp_Date_of_Birth")
	private Date emp_Date_of_Birth;
	
	@Transient
	private String emp_Date_of_Birth1;
	
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Column(name="emp_Date_of_Joining")
	private Date emp_Date_of_Joining;
	
	@Transient
	private String emp_Date_of_Joining1;
	
	@Column(name="emp_Dept_Id")
	private int emp_Dept_Id;
	
	@Column(name="emp_Grade")
	private String emp_Grade;
	
	@Size(min=2, max=50, message="Size should be btween 2 and 50")
	@Column(name="emp_Designation")
	private String emp_Designation;
	
	@NumberFormat(style = Style.NUMBER)
	@Column(name="emp_Basic")
	private int emp_Basic;
	
	@Column(name="emp_Gender")
	private String emp_Gender;
	
	@Column(name="emp_Marital_Status")
	private String emp_Marital_Status;
	
	@Column(name="emp_Home_Address")
	private String emp_Home_Address;
	
	@Pattern(regexp="(^$|[0-9]{10})", message="Please enter a valid Phone number")
	@Column(name="emp_Contact_Num")
	private String emp_Contact_Num;
	
	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public int getEmp_Id() {
		return emp_Id;
	}

	public void setEmp_Id(int emp_Id) {
		this.emp_Id = emp_Id;
	}

	public String getEmp_First_Name() {
		return emp_First_Name;
	}

	public void setEmp_First_Name(String emp_First_Name) {
		this.emp_First_Name = emp_First_Name;
	}

	public String getEmp_Last_Name() {
		return emp_Last_Name;
	}

	public void setEmp_Last_Name(String emp_Last_Name) {
		this.emp_Last_Name = emp_Last_Name;
	}

	public Date getEmp_Date_of_Birth() {
		return emp_Date_of_Birth;
	}

	public void setEmp_Date_of_Birth(Date emp_Date_of_Birth) {
		this.emp_Date_of_Birth = emp_Date_of_Birth;
	}

	public String getEmp_Date_of_Birth1() {
		return emp_Date_of_Birth1;
	}

	public void setEmp_Date_of_Birth1(String emp_Date_of_Birth1) {
		this.emp_Date_of_Birth1 = emp_Date_of_Birth1;
	}

	public Date getEmp_Date_of_Joining() {
		return emp_Date_of_Joining;
	}

	public void setEmp_Date_of_Joining(Date emp_Date_of_Joining) {
		this.emp_Date_of_Joining = emp_Date_of_Joining;
	}

	public String getEmp_Date_of_Joining1() {
		return emp_Date_of_Joining1;
	}

	public void setEmp_Date_of_Joining1(String emp_Date_of_Joining1) {
		this.emp_Date_of_Joining1 = emp_Date_of_Joining1;
	}

	public int getEmp_Dept_Id() {
		return emp_Dept_Id;
	}

	public void setEmp_Dept_Id(int emp_Dept_Id) {
		this.emp_Dept_Id = emp_Dept_Id;
	}

	public String getEmp_Grade() {
		return emp_Grade;
	}

	public void setEmp_Grade(String emp_Grade) {
		this.emp_Grade = emp_Grade;
	}

	public String getEmp_Designation() {
		return emp_Designation;
	}

	public void setEmp_Designation(String emp_Designation) {
		this.emp_Designation = emp_Designation;
	}

	public int getEmp_Basic() {
		return emp_Basic;
	}

	public void setEmp_Basic(int emp_Basic) {
		this.emp_Basic = emp_Basic;
	}

	public String getEmp_Gender() {
		return emp_Gender;
	}

	public void setEmp_Gender(String emp_Gender) {
		this.emp_Gender = emp_Gender;
	}

	public String getEmp_Marital_Status() {
		return emp_Marital_Status;
	}

	public void setEmp_Marital_Status(String emp_Marital_Status) {
		this.emp_Marital_Status = emp_Marital_Status;
	}

	public String getEmp_Home_Address() {
		return emp_Home_Address;
	}

	public void setEmp_Home_Address(String emp_Home_Address) {
		this.emp_Home_Address = emp_Home_Address;
	}

	public String getEmp_Contact_Num() {
		return emp_Contact_Num;
	}

	public void setEmp_Contact_Num(String emp_Contact_Num) {
		this.emp_Contact_Num = emp_Contact_Num;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + emp_Basic;
		result = prime * result
				+ ((emp_Contact_Num == null) ? 0 : emp_Contact_Num.hashCode());
		result = prime
				* result
				+ ((emp_Date_of_Birth == null) ? 0 : emp_Date_of_Birth
						.hashCode());
		result = prime
				* result
				+ ((emp_Date_of_Birth1 == null) ? 0 : emp_Date_of_Birth1
						.hashCode());
		result = prime
				* result
				+ ((emp_Date_of_Joining == null) ? 0 : emp_Date_of_Joining
						.hashCode());
		result = prime
				* result
				+ ((emp_Date_of_Joining1 == null) ? 0 : emp_Date_of_Joining1
						.hashCode());
		result = prime * result + emp_Dept_Id;
		result = prime * result
				+ ((emp_Designation == null) ? 0 : emp_Designation.hashCode());
		result = prime * result
				+ ((emp_First_Name == null) ? 0 : emp_First_Name.hashCode());
		result = prime * result
				+ ((emp_Gender == null) ? 0 : emp_Gender.hashCode());
		result = prime * result
				+ ((emp_Grade == null) ? 0 : emp_Grade.hashCode());
		result = prime
				* result
				+ ((emp_Home_Address == null) ? 0 : emp_Home_Address.hashCode());
		result = prime * result + emp_Id;
		result = prime * result
				+ ((emp_Last_Name == null) ? 0 : emp_Last_Name.hashCode());
		result = prime
				* result
				+ ((emp_Marital_Status == null) ? 0 : emp_Marital_Status
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (emp_Basic != other.emp_Basic)
			return false;
		if (emp_Contact_Num == null) {
			if (other.emp_Contact_Num != null)
				return false;
		} else if (!emp_Contact_Num.equals(other.emp_Contact_Num))
			return false;
		if (emp_Date_of_Birth == null) {
			if (other.emp_Date_of_Birth != null)
				return false;
		} else if (!emp_Date_of_Birth.equals(other.emp_Date_of_Birth))
			return false;
		if (emp_Date_of_Birth1 == null) {
			if (other.emp_Date_of_Birth1 != null)
				return false;
		} else if (!emp_Date_of_Birth1.equals(other.emp_Date_of_Birth1))
			return false;
		if (emp_Date_of_Joining == null) {
			if (other.emp_Date_of_Joining != null)
				return false;
		} else if (!emp_Date_of_Joining.equals(other.emp_Date_of_Joining))
			return false;
		if (emp_Date_of_Joining1 == null) {
			if (other.emp_Date_of_Joining1 != null)
				return false;
		} else if (!emp_Date_of_Joining1.equals(other.emp_Date_of_Joining1))
			return false;
		if (emp_Dept_Id != other.emp_Dept_Id)
			return false;
		if (emp_Designation == null) {
			if (other.emp_Designation != null)
				return false;
		} else if (!emp_Designation.equals(other.emp_Designation))
			return false;
		if (emp_First_Name == null) {
			if (other.emp_First_Name != null)
				return false;
		} else if (!emp_First_Name.equals(other.emp_First_Name))
			return false;
		if (emp_Gender == null) {
			if (other.emp_Gender != null)
				return false;
		} else if (!emp_Gender.equals(other.emp_Gender))
			return false;
		if (emp_Grade == null) {
			if (other.emp_Grade != null)
				return false;
		} else if (!emp_Grade.equals(other.emp_Grade))
			return false;
		if (emp_Home_Address == null) {
			if (other.emp_Home_Address != null)
				return false;
		} else if (!emp_Home_Address.equals(other.emp_Home_Address))
			return false;
		if (emp_Id != other.emp_Id)
			return false;
		if (emp_Last_Name == null) {
			if (other.emp_Last_Name != null)
				return false;
		} else if (!emp_Last_Name.equals(other.emp_Last_Name))
			return false;
		if (emp_Marital_Status == null) {
			if (other.emp_Marital_Status != null)
				return false;
		} else if (!emp_Marital_Status.equals(other.emp_Marital_Status))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Employee [emp_Id=" + emp_Id + ", emp_First_Name="
				+ emp_First_Name + ", emp_Last_Name=" + emp_Last_Name
				+ ", emp_Date_of_Birth=" + emp_Date_of_Birth
				+ ", emp_Date_of_Birth1=" + emp_Date_of_Birth1
				+ ", emp_Date_of_Joining=" + emp_Date_of_Joining
				+ ", emp_Date_of_Joining1=" + emp_Date_of_Joining1
				+ ", emp_Dept_Id=" + emp_Dept_Id + ", emp_Grade=" + emp_Grade
				+ ", emp_Designation=" + emp_Designation + ", emp_Basic="
				+ emp_Basic + ", emp_Gender=" + emp_Gender
				+ ", emp_Marital_Status=" + emp_Marital_Status
				+ ", emp_Home_Address=" + emp_Home_Address
				+ ", emp_Contact_Num=" + emp_Contact_Num + "]";
	}

	public Employee(int emp_Id, String emp_First_Name, String emp_Last_Name,
			Date emp_Date_of_Birth, String emp_Date_of_Birth1,
			Date emp_Date_of_Joining, String emp_Date_of_Joining1,
			int emp_Dept_Id, String emp_Grade, String emp_Designation,
			int emp_Basic, String emp_Gender, String emp_Marital_Status,
			String emp_Home_Address, String emp_Contact_Num) {
		super();
		this.emp_Id = emp_Id;
		this.emp_First_Name = emp_First_Name;
		this.emp_Last_Name = emp_Last_Name;
		this.emp_Date_of_Birth = emp_Date_of_Birth;
		this.emp_Date_of_Birth1 = emp_Date_of_Birth1;
		this.emp_Date_of_Joining = emp_Date_of_Joining;
		this.emp_Date_of_Joining1 = emp_Date_of_Joining1;
		this.emp_Dept_Id = emp_Dept_Id;
		this.emp_Grade = emp_Grade;
		this.emp_Designation = emp_Designation;
		this.emp_Basic = emp_Basic;
		this.emp_Gender = emp_Gender;
		this.emp_Marital_Status = emp_Marital_Status;
		this.emp_Home_Address = emp_Home_Address;
		this.emp_Contact_Num = emp_Contact_Num;
	}

	
}
