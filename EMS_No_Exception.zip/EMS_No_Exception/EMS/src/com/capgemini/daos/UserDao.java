package com.capgemini.daos;

import com.capgemini.entities.User;
import com.capgemini.exceptions.EMS_Exception;

public interface UserDao {
	
	User usrCheck(String usrName,String usrPass) throws EMS_Exception;

}
