package com.capgemini.services;

import com.capgemini.entities.User;
import com.capgemini.exceptions.EMS_Exception;

public interface UserService {
	
	User usrCheck(String usrName,String usrPass) throws EMS_Exception;

}
