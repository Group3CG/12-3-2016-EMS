package com.capgemini.services;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.daos.UserDao;
import com.capgemini.entities.User;
import com.capgemini.exceptions.EMS_Exception;

@Service
@Transactional
public class UserServiceImpl implements UserService {
	
	@Autowired
	UserDao userDao;


	@Override
	public User usrCheck(String usrName, String usrPass) throws EMS_Exception {
		return userDao.usrCheck(usrName, usrPass);
	}

}
